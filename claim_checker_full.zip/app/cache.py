import time

_CACHE = {}
TTL = 3600

def get(key):
    v = _CACHE.get(key)
    if not v: return None
    if time.time() - v[1] > TTL:
        _CACHE.pop(key, None)
        return None
    return v[0]

def set(key, value):
    _CACHE[key] = (value, time.time())
