import os

WEB_API_KEY = os.getenv("BING_API_KEY")
HF_API_KEY  = os.getenv("HF_API_KEY")

SEARCH_SOURCES = [
    ("CNN", "cnn.com", 0.8),
    ("Fox News", "foxnews.com", 0.6),
    ("JSTOR", "jstor.org", 1.0),
]
