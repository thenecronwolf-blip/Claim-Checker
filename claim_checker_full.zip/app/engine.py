import requests
from huggingface_hub import InferenceClient
from .config import WEB_API_KEY, HF_API_KEY, SEARCH_SOURCES
from .cache import get, set

client = InferenceClient(token=HF_API_KEY)

def web_search(query, site):
    cache_key = f"search:{query}:{site}"
    if get(cache_key): return get(cache_key)

    endpoint = "https://api.bing.microsoft.com/v7.0/search"
    headers = {"Ocp-Apim-Subscription-Key": WEB_API_KEY}
    params = {"q": f"{query} site:{site}", "count": 5}

    r = requests.get(endpoint, headers=headers, params=params, timeout=10)
    if r.status_code != 200:
        return []

    data = r.json()
    results = [
        {
            "title": i.get("name"),
            "url": i.get("url"),
            "snippet": i.get("snippet"),
        }
        for i in data.get("webPages", {}).get("value", [])
    ]
    set(cache_key, results)
    return results

def summarize(text):
    try:
        r = client.summarization(
            text,
            model="facebook/bart-large-cnn",
            generate_parameters={"max_length": 120, "min_length": 40},
        )
        return r.generated_text
    except:
        return None

def classify(summary):
    r = client.zero_shot_classification(
        sequences=summary,
        candidate_labels=[
            "supports the claim",
            "refutes the claim",
            "is neutral toward the claim",
        ],
        model="facebook/bart-large-mnli",
    )
    return r.labels[0], float(r.scores[0])

def assess(claim):
    explanation = []
    scores = {"pro":0,"con":0,"neutral":0}

    for source, domain, weight in SEARCH_SOURCES:
        for hit in web_search(claim, domain):
            summary = summarize(hit["snippet"])
            label, conf = classify(summary)
            stance = "pro" if "supports" in label else "con" if "refutes" in label else "neutral"
            weighted = conf * weight
            scores[stance] += weighted

            explanation.append({
                "source": source,
                "url": hit["url"],
                "summary": summary,
                "stance": stance,
                "confidence": round(weighted,3)
            })

    verdict = max(scores, key=scores.get).upper()
    return verdict, scores, explanation
