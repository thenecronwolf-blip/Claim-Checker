from fastapi import FastAPI
from slowapi import Limiter
from slowapi.util import get_remote_address
from .engine import assess

limiter = Limiter(key_func=get_remote_address)
app = FastAPI(title="Claim Checker")
app.state.limiter = limiter

@app.post("/assess")
@limiter.limit("5/minute")
def assess_claim(data: dict):
    verdict, scores, explanation = assess(data["claim"])
    return {
        "verdict": verdict,
        "scores": scores,
        "explanation": explanation
    }

@app.post("/assess/batch")
@limiter.limit("2/minute")
def assess_batch(data: dict):
    return {c: assess(c)[0] for c in data["claims"]}
